#!/usr/bin/env python3
"""Plot saved LMC experiments without importing or running the simulation code.

Place this file beside step_001_100000/ and step_01_200000/, then run:
    python plot_lmc_single_theory.py
It also works beside lmc_risk/, lmc_smoothness/ and lmc_stability/, including
their nested output folders. In Spyder, open the file and press F5.

If settings.json is absent, use the original grids in KNOWN_GRIDS below.
Array axes must be privacy: (alpha plus ERM, n, repetition), or smoothness:
(n, gamma, repetition). Matching shape alone cannot establish axis ordering.

Dependencies: numpy, pandas, matplotlib (already in the experiment requirements).
Each discovered study gets a plots_rms_slopes/ subfolder. Original files remain
unchanged. See --help for root, output, theory and slope-fit options.

Stability: sqrt EACH repetition's squared change, THEN average across reps.
Risk: retain mean SQUARED score risk. A risk bound is not a stability bound.
Dashed risk guides show exponents only, anchored at the first positive mean;
they omit constants and logarithms and are not fitted or guaranteed risk curves.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# Original experiment design. Used only when the arrays have no settings.json.
# Change these values only if the experiment was actually run on another grid.
KNOWN_GRIDS = dict(ns=[1000, 2000, 4000, 8000, 16000],
                   alphas=[0.5, 1.0, 2.0, 4.0, 8.0],
                   gammas=[0.2, 0.4, 0.6, 0.8, 1.0],
                   privacy_gamma=0.5, smoothness_alpha=2.0)


def risk_settings(folder, study, primary):
    settings_path = folder / "settings.json"
    if settings_path.exists():
        settings = json.loads(settings_path.read_text())
        if settings.get("study") != study:
            raise ValueError("Array directory and settings.json study disagree")
        source = "settings.json"
    else:
        if primary.ndim != 3 or primary.shape[-1] < 1:
            raise ValueError(f"Expected a three-dimensional risk array, got {primary.shape}")
        settings = dict(KNOWN_GRIDS, study=study, reps=primary.shape[-1])
        source = "known original grids; settings.json absent"
        expected = ((len(settings["alphas"]) + 1, len(settings["ns"])) if study == "privacy"
                    else (len(settings["ns"]), len(settings["gammas"])))
        if primary.shape[:2] != expected:
            raise ValueError(f"No settings.json: array shape {primary.shape} does not match "
                             f"the known {study} grid {expected} + repetitions. "
                             "Edit KNOWN_GRIDS only if your run used different grids.")
        print(f"No settings.json in {folder}: using original {study} grids "
              f"and {settings['reps']} saved repetitions.", flush=True)
    return settings, source


def exponent(gamma, dimension, component):
    denominator = dimension + (2 * gamma + 2 if component == "nonprivate" else gamma + 1)
    return -2 * gamma / denominator


def matrix(frame, value):
    """One independent repetition per column, paired over sample sizes."""
    if frame.duplicated(["n", "rep"]).any():
        raise ValueError(f"Duplicate (n, rep) rows for {value}")
    table = frame.pivot(index="n", columns="rep", values=value).sort_index().sort_index(axis=1)
    a = table.to_numpy(dtype=float)
    if not a.size or not np.isfinite(a).all() or (a < 0).any():
        raise ValueError(f"Incomplete, negative or non-finite observations for {value}")
    ns = table.index.to_numpy(dtype=float)
    if (ns <= 0).any():
        raise ValueError("Sample sizes must be positive")
    return ns, a


def slope(ns, values, args):
    means = values.mean(axis=1)
    use = (means > 0) & (ns >= args.min_n)
    if args.last_n:
        indices = np.flatnonzero(use)
        use[:] = False
        use[indices[-args.last_n:]] = True
    x = np.log(ns[use])
    if len(x) < 2:
        raise ValueError("Need at least two positive means at distinct n for a slope")
    y = np.log(means[use])
    centred = x - x.mean()
    weights = centred / (centred @ centred)
    b = float(weights @ y)
    fitted = y.mean() + b * centred
    sst = float(np.sum((y - y.mean()) ** 2))
    result = dict(empirical_slope=b, slope_se=np.nan, slope_ci_low=np.nan,
                  slope_ci_high=np.nan, fit_n_min=int(ns[use].min()),
                  fit_n_max=int(ns[use].max()), fit_points=len(x),
                  repetitions=values.shape[1],
                  log_fit_r_squared=1 - float(np.sum((y - fitted) ** 2)) / sst if sst else np.nan)
    if args.bootstrap and values.shape[1] > 1:
        # Resample whole repetition columns, preserving dependence across n.
        # Resetting the seed pairs the bootstrap across curves with the same reps.
        rng = np.random.default_rng(args.seed)
        indices = rng.integers(values.shape[1], size=(args.bootstrap, values.shape[1]))
        boot_means = values[use][:, indices].mean(axis=2)
        valid = (boot_means > 0).all(axis=0)
        boot_slopes = weights @ np.log(boot_means[:, valid])
        if len(boot_slopes) > 1:
            result.update(slope_se=float(boot_slopes.std(ddof=1)),
                          slope_ci_low=float(np.quantile(boot_slopes, .025)),
                          slope_ci_high=float(np.quantile(boot_slopes, .975)))
    return result


class Plotter:
    def __init__(self, folder, out, args):
        self.folder, self.out, self.args = folder, out, args
        self.slopes, self.summaries = [], []
        self.input_grid = None
        out.mkdir(parents=True, exist_ok=True)

    def add(self, ax, ns, values, label, colour, metric, estimator,
            alpha=np.nan, gamma=np.nan, theory=None, draw_theory=True):
        if (values.ndim != 2 or values.shape[0] != len(ns) or values.shape[1] < 1
                or not np.isfinite(values).all() or (values < 0).any()):
            raise ValueError(f"Incomplete or invalid observations for {label}, {metric}")
        stats = slope(ns, values, self.args)
        metadata = dict(metric=metric, estimator=estimator, alpha=alpha, gamma=gamma)
        self.slopes.append(dict(**metadata, **stats, theory_guide_exponent=theory,
                                nonprivate_risk_exponent=(exponent(gamma, self.args.dimension, "nonprivate")
                                                         if metric == "score_risk" else np.nan),
                                privacy_risk_exponent=(exponent(gamma, self.args.dimension, "privacy-term")
                                                      if metric == "score_risk" else np.nan)))
        mean = values.mean(axis=1)
        se = values.std(axis=1, ddof=1) / np.sqrt(values.shape[1]) if values.shape[1] > 1 else np.zeros(len(ns))
        for n, mu, error in zip(ns, mean, se):
            self.summaries.append(dict(**metadata, n=int(n), mean=float(mu), se=float(error),
                                       repetitions=values.shape[1]))
        legend = f"{label}: b={stats['empirical_slope']:.3f}"
        if theory is not None and draw_theory:
            legend += f" (theory: {theory:.3f})"
        keep = mean > 0
        # Lower error bars are shortened only when needed on the logarithmic axis.
        ax.errorbar(ns[keep], mean[keep],
                    yerr=np.vstack([np.minimum(se[keep], .99 * mean[keep]), se[keep]]),
                    color=colour, marker="o", linestyle="-", linewidth=1.3,
                    markersize=4, capsize=3, label=legend)
        if theory is not None and draw_theory:
            anchor = np.flatnonzero(keep)[0]
            guide = mean[anchor] * (ns / ns[anchor]) ** theory
            ax.plot(ns, guide, color=colour, linestyle="--", linewidth=1.2, alpha=.8)

    def finish(self, fig, axes, ns, filename, note):
        for ax in np.atleast_1d(axes):
            ax.set_xscale("log", base=2)
            ax.set_yscale("log", base=2)
            ax.set_xticks(ns, [str(int(n)) for n in ns])
            ax.set_xlabel("Sample size n")
            ax.grid(alpha=.2)
            ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(self.out / filename, dpi=200)
        plt.close(fig)

    def save_tables(self):
        pd.DataFrame(self.slopes).to_csv(self.out / "empirical_slopes.csv", index=False)
        pd.DataFrame(self.summaries).to_csv(self.out / "plot_summary.csv", index=False)
        (self.out / "plot_settings.json").write_text(json.dumps(dict(
            source_directory=str(self.folder), input_grid=self.input_grid, theory=self.args.theory,
            dimension=self.args.dimension, min_n=self.args.min_n, last_n=self.args.last_n,
            bootstrap=self.args.bootstrap, seed=self.args.seed,
            slope="OLS log(arithmetic mean across repetitions) against log(n)",
            rms="Mean across repetitions of sqrt(each repetition's squared change)",
            error_bars="One SE across independent repetitions; lower bars clipped at positive values for log axes",
            slope_uncertainty="Whole-repetition paired bootstrap across n; percentile 95% CI",
            theory_interpretation="Risk exponent guides anchored at first positive mean; constants and logs omitted; no stability theorem assumed",
            sampler="Saved finite-iteration outputs; no MCMC bias correction"), indent=2) + "\n")


def stability(folder, out, args):
    frame = pd.read_csv(folder / "coefficient_stability.csv")
    required = ["n", "rep", "alpha", "gamma", "private_coefficient_mse",
                "erm_coefficient_mse", "private_score_squared", "erm_score_squared"]
    missing = set(required) - set(frame)
    if missing:
        raise ValueError(f"Missing stability columns: {sorted(missing)}")
    if frame.duplicated(["n", "rep", "alpha", "gamma"]).any():
        raise ValueError("Duplicate stability rows")
    if frame.gamma.nunique() != 1:
        raise ValueError("Use separate stability directories for different gamma values")
    # Different replacements must never be silently pooled into repetitions.
    for column in ("replacement_index", "replacement_value", "steps"):
        if column in frame and frame[column].nunique() != 1:
            raise ValueError(f"Mixed {column} settings in stability CSV")
    p = Plotter(folder, out, args)
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.3))
    alphas = sorted(frame.alpha.unique())
    ns_all = sorted(frame.n.unique())
    gamma = float(frame.gamma.iloc[0])
    for ax, source, metric, ylabel in zip(
            axes, ("coefficient_mse", "score_squared"), ("coefficient_rms", "score_rms"),
            ("Coefficient RMS change", "Score RMS change")):
        for estimator in ("private", "erm"):
            column = estimator + "_" + source
            raw = frame[column].to_numpy(dtype=float)
            if not np.isfinite(raw).all() or (raw < 0).any():
                raise ValueError(f"Invalid squared changes in {column}")
            frame["rms"] = np.sqrt(raw)
            blocks = [matrix(frame[frame.alpha == a], "rms") for a in alphas]
            shared = estimator == "erm" and all(
                np.array_equal(blocks[0][0], ns) and blocks[0][1].shape == v.shape
                and np.allclose(blocks[0][1], v, rtol=1e-8, atol=1e-12)
                and np.array_equal(np.sort(frame[frame.alpha == alphas[0]].rep.unique()),
                                   np.sort(frame[frame.alpha == a].rep.unique()))
                for a, (ns, v) in zip(alphas, blocks))
            for k, (a, (ns, values)) in enumerate(zip(alphas, blocks)):
                if shared and k:
                    continue
                label = (rf"$\alpha={a:g}$" if estimator == "private" else
                         "ERM" if shared else rf"ERM, $\alpha={a:g}$")
                colour = "black" if shared else plt.get_cmap("tab10")(k)
                if estimator == "erm" and not shared:
                    colour = plt.get_cmap("tab20")(2 * k + 1)
                p.add(ax, ns, values, label, colour, metric, estimator,
                      alpha=np.nan if shared else a, gamma=gamma)
        ax.set_ylabel(ylabel)
    p.finish(fig, axes, ns_all, "coefficient_stability_rms.png",
             "Mean of per-repetition RMS changes ±1 SE; b = empirical log–log slope. No theoretical stability exponent assumed.")
    p.save_tables()


def risk(folder, out, args, study):
    primary = np.load(folder / f"{study}_risk.npy", allow_pickle=False)
    settings, settings_source = risk_settings(folder, study, primary)
    ns = np.asarray(settings["ns"], dtype=float)
    if len(np.unique(ns)) != len(ns) or (ns <= 0).any():
        raise ValueError("Invalid sample-size grid")
    order = np.argsort(ns)
    ns = ns[order]
    p = Plotter(folder, out, args)
    p.input_grid = dict(source=settings_source,
                       **{key:settings[key] for key in KNOWN_GRIDS},
                       repetitions=settings["reps"],
                       axes=(["alpha_plus_ERM", "n", "repetition"] if study == "privacy"
                             else ["n", "gamma", "repetition"]))
    if study == "privacy":
        alphas, gamma = settings["alphas"], float(settings["privacy_gamma"])
        expected = (len(alphas) + 1, len(ns), settings["reps"])
        if primary.shape != expected:
            raise ValueError(f"Privacy shape {primary.shape}, expected {expected}")
        fig, ax = plt.subplots(figsize=(9.5, 6))
        for i, alpha in enumerate(alphas):
            p.add(ax, ns, primary[i, order], rf"$\alpha={alpha:g}$", plt.get_cmap("tab10")(i),
                  "score_risk", "private", alpha=alpha, gamma=gamma,
                  theory=exponent(gamma, args.dimension, args.theory), draw_theory=False)
        p.add(ax, ns, primary[-1, order], "ERM", "black", "score_risk", "erm", gamma=gamma,
              theory=exponent(gamma, args.dimension, "nonprivate"), draw_theory=False)
        # One reference exponent suffices at fixed gamma. Its vertical position
        # is arbitrary: anchor it to the first positive ERM mean for reproducibility.
        reference_slope = exponent(gamma, args.dimension, args.theory)
        erm_mean = primary[-1, order].mean(axis=1)
        anchor = np.flatnonzero(erm_mean > 0)[0]
        guide = erm_mean[anchor] * (ns / ns[anchor]) ** reference_slope
        component = " (privacy term)" if args.theory == "privacy-term" else ""
        ax.plot(ns, guide, color="black", linestyle="--", linewidth=1.5,
                label=f"Theoretical slope: {reference_slope:.3f}{component}")
        p.input_grid["privacy_theory_reference"] = dict(
            exponent=reference_slope, anchor="first positive ERM mean",
            explanation="Single exponent reference; arbitrary vertical normalisation")
        ax.set_ylabel("Mean squared score risk")
        axes = [ax]
        filename = "n_privacy_risk_slopes.png"
    else:
        gammas, alpha = settings["gammas"], float(settings["smoothness_alpha"])
        erms = np.load(folder / "smoothness_erm_risk.npy", allow_pickle=False)
        expected = (len(ns), len(gammas), settings["reps"])
        if primary.shape != expected or erms.shape != expected:
            raise ValueError(f"Smoothness arrays must have shape {expected}")
        fig, axes = plt.subplots(1, 2, figsize=(14, 5.3), sharey=True)
        for j, gamma in enumerate(gammas):
            for ax, values, estimator in zip(axes, (primary, erms), ("private", "erm")):
                component = args.theory if estimator == "private" else "nonprivate"
                p.add(ax, ns, values[order, j], rf"$\gamma={gamma:g}$", plt.get_cmap("tab10")(j),
                      "score_risk", estimator, alpha=alpha if estimator == "private" else np.nan,
                      gamma=gamma, theory=exponent(gamma, args.dimension, component))
        axes[0].set_ylabel("Private mean squared score risk")
        axes[1].set_ylabel("ERM mean squared score risk")
        filename = "n_smoothness_risk_slopes.png"
    if not np.isfinite(primary).all() or (primary < 0).any():
        plt.close(fig)
        raise ValueError("Risk study is incomplete or contains invalid values")
    if study == "smoothness" and (not np.isfinite(erms).all() or (erms < 0).any()):
        plt.close(fig)
        raise ValueError("ERM study is incomplete or contains invalid values")
    note = ("Solid: empirical mean ±1 SE; b: empirical log–log slope. "
            "Dashed: " + ("non-private rate exponent" if args.theory == "nonprivate" else
                          "privacy-term exponent for private curves; non-private exponent for ERM")
            + ", anchored at first n (constants/logs omitted).")
    p.finish(fig, axes, ns, filename, note)
    p.save_tables()


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parent,
                        help="Folder to search recursively; default is this script's folder")
    parser.add_argument("--output-dir", type=Path,
                        help="Optional output root, preserving relative study paths")
    parser.add_argument("--theory", choices=("nonprivate", "privacy-term"), default="nonprivate",
                        help="Private risk guide; default uses non-private exponent for BOTH estimators, as requested")
    parser.add_argument("--dimension", type=int, default=1, help="Statistical dimension d; default 1")
    parser.add_argument("--min-n", type=float, default=0, help="Minimum n included in slope fits only")
    parser.add_argument("--last-n", type=int, default=0, help="Fit only the last k sample sizes; 0 uses all")
    parser.add_argument("--bootstrap", type=int, default=2000,
                        help="Paired bootstrap replicates for slope SE/CI; 0 disables")
    parser.add_argument("--seed", type=int, default=1)
    args = parser.parse_args()
    if args.dimension < 1 or args.bootstrap < 0 or args.last_n < 0 or args.last_n == 1 or not np.isfinite(args.min_n) or args.min_n < 0 or args.seed < 0:
        parser.error("Require dimension>=1, bootstrap>=0, last-n=0 or >=2, finite min-n>=0, seed>=0")
    args.root = args.root.resolve()
    if not args.root.is_dir():
        parser.error(f"Not a directory: {args.root}")
    jobs = []
    for name, study in (("coefficient_stability.csv", "stability"),
                        ("privacy_risk.npy", "privacy"), ("smoothness_risk.npy", "smoothness")):
        jobs.extend((path.parent, study) for path in args.root.rglob(name)
                    if "plots_rms_slopes" not in path.parts and
                    not (args.output_dir and args.output_dir.resolve() in path.resolve().parents))
    if not jobs:
        parser.error("No coefficient_stability.csv, privacy_risk.npy or smoothness_risk.npy found")
    failures = []
    for folder, study in sorted(jobs):
        relative = folder.relative_to(args.root)
        out = ((args.output_dir.resolve() / relative) if args.output_dir else folder / "plots_rms_slopes")
        # The normal bundle has one study per folder. Prevent accidental overwrites.
        if sum(other == folder for other, _ in jobs) > 1:
            out /= study
        try:
            if study == "stability":
                stability(folder, out, args)
            else:
                risk(folder, out, args, study)
            print(f"Saved {study}: {out}", flush=True)
        except (ValueError, KeyError, OSError, TypeError) as error:
            plt.close("all")
            failures.append(f"{folder} ({study}): {error}")
            print(f"FAILED: {failures[-1]}", file=sys.stderr, flush=True)
    if failures:
        print(f"{len(failures)} study/studies failed; other completed plots were saved.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
